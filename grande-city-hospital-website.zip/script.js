const form = document.getElementById("appointmentForm");
const modal = document.getElementById("successModal");
const summary = document.getElementById("summary");
const dateInput = document.getElementById("date");
document.getElementById("year").textContent = new Date().getFullYear();

const today = new Date();
dateInput.min = today.toISOString().split("T")[0];

document.querySelector(".menu-toggle").addEventListener("click", () => {
  document.getElementById("nav").classList.toggle("open");
});
document.querySelectorAll("#nav a").forEach(a => a.addEventListener("click", () => {
  document.getElementById("nav").classList.remove("open");
}));

function prefill(dept){
  document.getElementById("department").value = dept;
  document.getElementById("appointment").scrollIntoView({behavior:"smooth", block:"center"});
}

form.addEventListener("submit", e => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(form).entries());
  const when = `${data.date} at ${data.time}`;
  summary.textContent = `${data.name}, your request for ${data.department} has been recorded for ${when}. Phone: ${data.phone}.`;
  localStorage.setItem("lastAppointment", JSON.stringify(data));
  modal.classList.add("show");
  form.reset();
  dateInput.min = today.toISOString().split("T")[0];
});
function closeModal(){ modal.classList.remove("show"); }
modal.addEventListener("click", e => { if(e.target === modal) closeModal(); });
