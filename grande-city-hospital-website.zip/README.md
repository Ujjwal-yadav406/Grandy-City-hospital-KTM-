# Grande City Hospital Pvt. Ltd. — Website Demo

This is a static, mobile-responsive hospital website demo.

## Included
- Responsive home page
- Departments and services
- Doctor cards
- Health packages
- Contact section
- FAQ
- Online appointment form
- Appointment confirmation modal
- Local browser storage for the last submitted appointment
- No server required for the demo

## Important before selling/publishing
The content in this demo contains sample/placeholder information (including phone/email, doctors, location and service claims). Verify every hospital detail with Grande City Hospital before public use.

The appointment form is a front-end demo. It does NOT send appointments to the hospital. For a real production system, connect it to a secure backend/database, email service, or a hospital-approved WhatsApp/SMS workflow. Patient information should be handled securely and in accordance with applicable privacy requirements.

## GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `style.css`, and `script.js`.
3. In Settings → Pages, select the main branch/root folder.
4. Save and open the GitHub Pages URL.

